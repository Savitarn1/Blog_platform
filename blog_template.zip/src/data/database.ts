export const users = [
  {id:0,login:'admin',password:'admindata' , name:'Admin'},
  {id:1,login:'dilorom',password:'dilorom123' , name:'Dilorom'},
  {id:2,login:'dalerbek',password:'dalerbek123' , name:'Dalerbek'},
  {id:3,login:'savitar',password:'uzuhiko' , name:'Savitar'},
]